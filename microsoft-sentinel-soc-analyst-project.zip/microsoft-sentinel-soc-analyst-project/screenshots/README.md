# Screenshots

Place your lab screenshots in this folder.

Suggested filenames:

- `01-sentinel-incident.png`
- `02-failed-signins.png`
- `03-success-after-failures.png`
- `04-geographic-anomaly.png`
- `05-powershell-hunt.png`
- `06-device-timeline.png`
- `07-final-incident-timeline.png`

Do not upload real confidential security data.
